import React from 'react'
import { motion } from "framer-motion";
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"

const EditBook = () => {
  return (
    <>
      <h2 className='text-center text-3xl my-3 tracking-wider uppercase font-bold'>Edit Book</h2>
      <div className='flex justify-around content-between'>
        <div>
          <img src="https://m.media-amazon.com/images/I/61mjnP-qt6L._AC_UF1000,1000_QL80_.jpg"
            className='h-96 w-72 my-6'
            alt="" />
        </div>
        <form className="w-full max-w-lg">

          <div className="flex flex-wrap -mx-3 my-6 gap-4">
            {/* shadecn */} {/* name */}
            <div className="w-full px-3">
              <Label htmlFor="name">NAME</Label>
              <Input
                id="name"
                placeholder="Name of the book"
                className="focus-visible:ring-1" />{/* border-red-500 */}
              {/* <p className="text-red-500 text-xs italic">Please fill out this field.</p> */}
            </div>

            {/* shadecn */} {/* author */}
            <div className="w-full px-3">
              <Label htmlFor="author">AUTHOR</Label>
              <Input
                id="author"
                placeholder="Author of the book"
                className="focus-visible:ring-1" />{/* border-red-500 */}
              {/* <p className="text-red-500 text-xs italic">Please fill out this field.</p> */}
            </div>

            {/* shadecn */} {/* publisher */}
            <div className="w-full px-3">
              <Label htmlFor="publisher">PUBLISHER</Label>
              <Input
                id="publisher"
                placeholder="Publisher of the book"
                className="focus-visible:ring-1" />{/* border-red-500 */}
              {/* <p className="text-red-500 text-xs italic">Please fill out this field.</p> */}
            </div>

            {/* shadecn */} {/* isbn */}
            <div className="w-full px-3">
              <Label htmlFor="isbn">ISBN</Label>
              <Input
                id="isbn"
                placeholder="ISBN of the book"
                className="focus-visible:ring-1" />{/* border-red-500 */}
              {/* <p className="text-red-500 text-xs italic">Please fill out this field.</p> */}
            </div>

            {/* shadecn */} {/* Picture */}
            <div className="w-full px-3">
              <Label htmlFor="picture">Picture</Label>
              <Input id="picture" type="file" />
              {/* <p className="text-red-500 text-xs italic">Please fill out this field.</p> */}
            </div>

          </div>
          {/* submit button */}
          <motion.div
            whileHover={{ scale: 1.05 }}
            whileTap={{ scale: 0.9 }}>
            {/* <Link to={path}> */}
            <button className="w-full shadow bg-primary focus:shadow-outline focus:outline-none text-white font-bold text-base py-2 px-4 rounded" type="submit">
              Submit
            </button>
            {/* </Link> */}
          </motion.div>
        </form>
      </div>
    </>
  )
}

export default EditBook
import React from 'react'

const Analystics = () => {
  return (
    <div>Analystics</div>
  )
}

export default Analystics